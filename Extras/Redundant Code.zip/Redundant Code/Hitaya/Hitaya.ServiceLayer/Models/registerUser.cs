﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hitaya.ServiceLayer.Models
{
    public class registerUser
    {
        public string FIRSTNAME { get; set; }
        public string LASTNAME { get; set; }
        public string EMAILID { get; set; }
        public string PASSWORD { get; set; }
    }
}